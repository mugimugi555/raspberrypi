__version__ = '2.8.0'
__git_version__ = '0.6.0-126264-gdd24786a398'
